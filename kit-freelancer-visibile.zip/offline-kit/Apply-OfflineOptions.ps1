#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$module = Join-Path $PSScriptRoot 'lib\PeacockOffline.psm1'
Import-Module $module -Force -DisableNameChecking

$dir = Resolve-PackagedPeacockDir
Set-OfflineFriendlyOptions $dir
Restore-OwnedWoaEntitlements $dir
Write-Host ''
Write-Host 'Nota: al primo avvio Peacock puo leggere i DLC da Epic o Steam (il negozio dell exe), non da Xbox Game Pass.' -ForegroundColor DarkGray
Write-Host 'Dopo un login riuscito, il profilo in userdata\ conserva gli unlock e puoi giocare offline.' -ForegroundColor DarkGray
if ($Host.Name -eq 'ConsoleHost') {
    Write-Host 'Premi un tasto per chiudere...' -ForegroundColor DarkGray
    [void][System.Console]::ReadKey($true)
}
